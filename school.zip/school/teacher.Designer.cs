﻿namespace school
{
    partial class teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.查询个人信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询课程信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生成绩ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.账号切换ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查询个人信息ToolStripMenuItem,
            this.查询课程信息ToolStripMenuItem,
            this.学生成绩ToolStripMenuItem,
            this.修改密码ToolStripMenuItem,
            this.系统设置ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(777, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 查询个人信息ToolStripMenuItem
            // 
            this.查询个人信息ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.查询个人信息ToolStripMenuItem.Name = "查询个人信息ToolStripMenuItem";
            this.查询个人信息ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.查询个人信息ToolStripMenuItem.Text = "查询个人信息";
            this.查询个人信息ToolStripMenuItem.Click += new System.EventHandler(this.查询个人信息ToolStripMenuItem_Click);
            // 
            // 查询课程信息ToolStripMenuItem
            // 
            this.查询课程信息ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.查询课程信息ToolStripMenuItem.Name = "查询课程信息ToolStripMenuItem";
            this.查询课程信息ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.查询课程信息ToolStripMenuItem.Text = "查询课程信息";
            this.查询课程信息ToolStripMenuItem.Click += new System.EventHandler(this.查询课程信息ToolStripMenuItem_Click);
            // 
            // 学生成绩ToolStripMenuItem
            // 
            this.学生成绩ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.学生成绩ToolStripMenuItem.Name = "学生成绩ToolStripMenuItem";
            this.学生成绩ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.学生成绩ToolStripMenuItem.Text = "学生成绩";
            this.学生成绩ToolStripMenuItem.Click += new System.EventHandler(this.学生成绩ToolStripMenuItem_Click);
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            this.修改密码ToolStripMenuItem.Click += new System.EventHandler(this.修改密码ToolStripMenuItem_Click);
            // 
            // 系统设置ToolStripMenuItem
            // 
            this.系统设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.账号切换ToolStripMenuItem,
            this.退出系统ToolStripMenuItem});
            this.系统设置ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.系统设置ToolStripMenuItem.Name = "系统设置ToolStripMenuItem";
            this.系统设置ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.系统设置ToolStripMenuItem.Text = "系统设置";
            // 
            // 账号切换ToolStripMenuItem
            // 
            this.账号切换ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.账号切换ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.账号切换ToolStripMenuItem.Name = "账号切换ToolStripMenuItem";
            this.账号切换ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.账号切换ToolStripMenuItem.Text = "账号切换";
            this.账号切换ToolStripMenuItem.Click += new System.EventHandler(this.账号切换ToolStripMenuItem_Click);
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.退出系统ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.退出系统ToolStripMenuItem.Text = "退出系统";
            this.退出系统ToolStripMenuItem.Click += new System.EventHandler(this.退出系统ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(777, 446);
            this.panel1.TabIndex = 2;
            // 
            // teacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(777, 477);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "teacher";
            this.Text = "欢迎您：老师";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.teacher_FormClosing);
            this.Load += new System.EventHandler(this.teacher_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 查询个人信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询课程信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生成绩ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem 系统设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 账号切换ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;

    }
}