﻿namespace school
{
    partial class admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.学生信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加新学生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生奖惩信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加新教师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.课程信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加新课程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.系统设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.账号切换ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用户注册ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(25)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生信息管理ToolStripMenuItem,
            this.教师信息管理ToolStripMenuItem,
            this.课程信息管理ToolStripMenuItem,
            this.修改密码ToolStripMenuItem,
            this.系统设置ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(775, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 学生信息管理ToolStripMenuItem
            // 
            this.学生信息管理ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.学生信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生信息查询ToolStripMenuItem,
            this.添加新学生ToolStripMenuItem,
            this.学生奖惩信息ToolStripMenuItem,
            this.班级信息查询ToolStripMenuItem});
            this.学生信息管理ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.学生信息管理ToolStripMenuItem.Name = "学生信息管理ToolStripMenuItem";
            this.学生信息管理ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.学生信息管理ToolStripMenuItem.Text = "学生信息管理";
            // 
            // 学生信息查询ToolStripMenuItem
            // 
            this.学生信息查询ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.学生信息查询ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.学生信息查询ToolStripMenuItem.Name = "学生信息查询ToolStripMenuItem";
            this.学生信息查询ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.学生信息查询ToolStripMenuItem.Text = "学生信息查询";
            this.学生信息查询ToolStripMenuItem.Click += new System.EventHandler(this.学生信息查询ToolStripMenuItem_Click);
            // 
            // 添加新学生ToolStripMenuItem
            // 
            this.添加新学生ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.添加新学生ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.添加新学生ToolStripMenuItem.Name = "添加新学生ToolStripMenuItem";
            this.添加新学生ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.添加新学生ToolStripMenuItem.Text = "添加新学生";
            this.添加新学生ToolStripMenuItem.Click += new System.EventHandler(this.添加新学生ToolStripMenuItem_Click);
            // 
            // 学生奖惩信息ToolStripMenuItem
            // 
            this.学生奖惩信息ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.学生奖惩信息ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.学生奖惩信息ToolStripMenuItem.Name = "学生奖惩信息ToolStripMenuItem";
            this.学生奖惩信息ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.学生奖惩信息ToolStripMenuItem.Text = "学生奖惩信息";
            this.学生奖惩信息ToolStripMenuItem.Click += new System.EventHandler(this.学生奖惩信息ToolStripMenuItem_Click);
            // 
            // 班级信息查询ToolStripMenuItem
            // 
            this.班级信息查询ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.班级信息查询ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.班级信息查询ToolStripMenuItem.Name = "班级信息查询ToolStripMenuItem";
            this.班级信息查询ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.班级信息查询ToolStripMenuItem.Text = "班级信息查询";
            this.班级信息查询ToolStripMenuItem.Click += new System.EventHandler(this.班级信息查询ToolStripMenuItem_Click);
            // 
            // 教师信息管理ToolStripMenuItem
            // 
            this.教师信息管理ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.教师信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.教师信息查询ToolStripMenuItem,
            this.添加新教师ToolStripMenuItem});
            this.教师信息管理ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.教师信息管理ToolStripMenuItem.Name = "教师信息管理ToolStripMenuItem";
            this.教师信息管理ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.教师信息管理ToolStripMenuItem.Text = "教师信息管理";
            // 
            // 教师信息查询ToolStripMenuItem
            // 
            this.教师信息查询ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.教师信息查询ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.教师信息查询ToolStripMenuItem.Name = "教师信息查询ToolStripMenuItem";
            this.教师信息查询ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.教师信息查询ToolStripMenuItem.Text = "教师信息查询";
            this.教师信息查询ToolStripMenuItem.Click += new System.EventHandler(this.教师信息查询ToolStripMenuItem_Click);
            // 
            // 添加新教师ToolStripMenuItem
            // 
            this.添加新教师ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.添加新教师ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.添加新教师ToolStripMenuItem.Name = "添加新教师ToolStripMenuItem";
            this.添加新教师ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.添加新教师ToolStripMenuItem.Text = "添加新教师";
            this.添加新教师ToolStripMenuItem.Click += new System.EventHandler(this.添加新教师ToolStripMenuItem_Click);
            // 
            // 课程信息管理ToolStripMenuItem
            // 
            this.课程信息管理ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.课程信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.课程信息查询ToolStripMenuItem,
            this.添加新课程ToolStripMenuItem});
            this.课程信息管理ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.课程信息管理ToolStripMenuItem.Name = "课程信息管理ToolStripMenuItem";
            this.课程信息管理ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.课程信息管理ToolStripMenuItem.Text = "课程信息管理";
            // 
            // 课程信息查询ToolStripMenuItem
            // 
            this.课程信息查询ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.课程信息查询ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.课程信息查询ToolStripMenuItem.Name = "课程信息查询ToolStripMenuItem";
            this.课程信息查询ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.课程信息查询ToolStripMenuItem.Text = "课程信息查询";
            this.课程信息查询ToolStripMenuItem.Click += new System.EventHandler(this.课程信息查询ToolStripMenuItem_Click);
            // 
            // 添加新课程ToolStripMenuItem
            // 
            this.添加新课程ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.添加新课程ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.添加新课程ToolStripMenuItem.Name = "添加新课程ToolStripMenuItem";
            this.添加新课程ToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.添加新课程ToolStripMenuItem.Text = "添加新课程";
            this.添加新课程ToolStripMenuItem.Click += new System.EventHandler(this.添加新课程ToolStripMenuItem_Click);
            // 
            // 修改密码ToolStripMenuItem
            // 
            this.修改密码ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.修改密码ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.修改密码ToolStripMenuItem.Name = "修改密码ToolStripMenuItem";
            this.修改密码ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.修改密码ToolStripMenuItem.Text = "修改密码";
            this.修改密码ToolStripMenuItem.Click += new System.EventHandler(this.修改密码ToolStripMenuItem_Click);
            // 
            // 系统设置ToolStripMenuItem
            // 
            this.系统设置ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.系统设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.账号切换ToolStripMenuItem,
            this.退出系统ToolStripMenuItem,
            this.用户注册ToolStripMenuItem});
            this.系统设置ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.系统设置ToolStripMenuItem.Name = "系统设置ToolStripMenuItem";
            this.系统设置ToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.系统设置ToolStripMenuItem.Text = "系统设置";
            // 
            // 账号切换ToolStripMenuItem
            // 
            this.账号切换ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.账号切换ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.账号切换ToolStripMenuItem.Name = "账号切换ToolStripMenuItem";
            this.账号切换ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.账号切换ToolStripMenuItem.Text = "账号切换";
            this.账号切换ToolStripMenuItem.Click += new System.EventHandler(this.账号切换ToolStripMenuItem_Click);
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.退出系统ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.退出系统ToolStripMenuItem.Text = "退出系统";
            this.退出系统ToolStripMenuItem.Click += new System.EventHandler(this.退出系统ToolStripMenuItem_Click);
            // 
            // 用户注册ToolStripMenuItem
            // 
            this.用户注册ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.用户注册ToolStripMenuItem.ForeColor = System.Drawing.Color.Blue;
            this.用户注册ToolStripMenuItem.Name = "用户注册ToolStripMenuItem";
            this.用户注册ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.用户注册ToolStripMenuItem.Text = "用户注册";
            this.用户注册ToolStripMenuItem.Click += new System.EventHandler(this.用户注册ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(775, 455);
            this.panel1.TabIndex = 1;
            // 
            // admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(228)))), ((int)(((byte)(253)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(775, 483);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "admin";
            this.Text = "欢迎您：管理员";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.admin_FormClosing);
            this.Load += new System.EventHandler(this.admin_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 学生信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生信息查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加新学生ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师信息查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加新教师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 课程信息查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加新课程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生奖惩信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级信息查询ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem 系统设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 账号切换ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 用户注册ToolStripMenuItem;
    }
}